package com.dbs.edge.service.extension;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExtensionApplicationTests {

	@Test
	void contextLoads() {
	}

}
