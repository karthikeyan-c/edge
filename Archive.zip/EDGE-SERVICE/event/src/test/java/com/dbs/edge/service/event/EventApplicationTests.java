package com.dbs.edge.service.event;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventApplicationTests {

	@Test
	void contextLoads() {
	}

}
