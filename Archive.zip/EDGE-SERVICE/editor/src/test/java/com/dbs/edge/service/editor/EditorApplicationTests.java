package com.dbs.edge.service.editor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EditorApplicationTests {

	@Test
	void contextLoads() {
	}

}
