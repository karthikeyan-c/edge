package com.dbs.edge.transaction.core;

import org.springframework.stereotype.Service;

@Service
public class TestService {
    public String replyService () {
        return "reply from service";
    }
}
